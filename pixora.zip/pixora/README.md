# Pixora – Setup (Hinglish)

## 1. API keys lo
- **Google**: console.cloud.google.com → APIs & Services → Credentials → OAuth Client ID (Web). "Authorized JavaScript origins" me apna Render URL daalo (https://pixora.onrender.com). Client ID = GOOGLE_CLIENT_ID.
- **fal.ai**: fal.ai/dashboard/keys → key banao, credit add karo → FAL_KEY.
- **Razorpay**: Dashboard → Subscriptions → Plans → naya plan (₹99, Monthly) → plan_id = RAZORPAY_PLAN_ID. Settings → API Keys → KEY_ID / KEY_SECRET.
  Webhook: Settings → Webhooks → URL `https://TUMHARA-URL/api/webhook`, secret khud likho (RAZORPAY_WEBHOOK_SECRET), events: subscription.activated, charged, cancelled, halted, completed, paused.

## 2. GitHub
Is folder ko GitHub repo me push karo (.env kabhi push mat karna).

## 3. Render
New → Blueprint → repo select (render.yaml se web + database ban jayega). Environment me .env.example wali baaki keys bharo. Deploy.

## 4. Test
Pehle Razorpay **Test mode** keys se ek payment test karo, phir Live keys lagao.
