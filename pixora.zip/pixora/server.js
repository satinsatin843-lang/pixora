const express = require('express');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { Pool } = require('pg');
const { OAuth2Client } = require('google-auth-library');
const path = require('path');

const E = process.env;
const TRIAL_DAYS = +E.TRIAL_DAYS || 3;
const DAILY_LIMIT = +E.DAILY_LIMIT || 60;
const DAY = 864e5;
const pool = new Pool({ connectionString: E.DATABASE_URL, ssl: E.DATABASE_URL && !E.DATABASE_URL.includes('localhost') ? { rejectUnauthorized: false } : false });
const gclient = new OAuth2Client(E.GOOGLE_CLIENT_ID);
const app = express();
app.set('trust proxy', 1);

const MODELS = { fast: 'fal-ai/flux/schnell', pro: 'fal-ai/flux/dev', ultra: 'fal-ai/flux-pro/v1.1' };
const SIZES = { square: 'square_hd', portrait: 'portrait_4_3', tall: 'portrait_16_9', wide: 'landscape_16_9', landscape: 'landscape_4_3' };
const STYLES = {
  none: '', cinematic: ', cinematic lighting, shallow depth of field, film grain, 35mm', photo: ', ultra realistic photograph, natural light, sharp focus, 8k',
  anime: ', anime style, vibrant colors, clean line art, studio quality', art3d: ', 3d render, octane render, soft studio lighting, detailed',
  paint: ', digital painting, rich brushwork, concept art, artstation', logo: ', minimal vector logo, flat design, white background'
};

async function init() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users(
      id SERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT, pass_hash TEXT,
      created_at TIMESTAMPTZ DEFAULT now(), sub_id TEXT, sub_status TEXT, sub_end TIMESTAMPTZ);
    CREATE TABLE IF NOT EXISTS images(
      id SERIAL PRIMARY KEY, user_id INT REFERENCES users(id) ON DELETE CASCADE,
      url TEXT NOT NULL, prompt TEXT, model TEXT, created_at TIMESTAMPTZ DEFAULT now());
    CREATE INDEX IF NOT EXISTS img_user ON images(user_id, created_at DESC);`);
}

// ---- Razorpay webhook (raw body, must be before json parser)
app.post('/api/webhook', express.raw({ type: '*/*' }), async (req, res) => {
  try {
    const sig = req.headers['x-razorpay-signature'];
    const expect = crypto.createHmac('sha256', E.RAZORPAY_WEBHOOK_SECRET || '').update(req.body).digest('hex');
    if (!sig || sig.length !== expect.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expect))) return res.sendStatus(400);
    const ev = JSON.parse(req.body.toString());
    const s = ev.payload && ev.payload.subscription && ev.payload.subscription.entity;
    if (s) {
      const end = s.current_end ? new Date(s.current_end * 1000) : null;
      await pool.query('UPDATE users SET sub_status=$1, sub_end=COALESCE($2, sub_end) WHERE sub_id=$3', [s.status, end, s.id]);
    }
    res.sendStatus(200);
  } catch (e) { console.error(e); res.sendStatus(500); }
});

app.use(express.json({ limit: '50kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/', rateLimit({ windowMs: 60e3, max: 60 }));

// ---- helpers
const setCookie = (res, u) => res.cookie('t', jwt.sign({ id: u.id }, E.JWT_SECRET, { expiresIn: '30d' }),
  { httpOnly: true, secure: true, sameSite: 'lax', maxAge: 30 * DAY });
async function auth(req, res, next) {
  try {
    const { id } = jwt.verify(req.cookies.t, E.JWT_SECRET);
    const r = await pool.query('SELECT * FROM users WHERE id=$1', [id]);
    if (!r.rows[0]) throw 0;
    req.user = r.rows[0]; next();
  } catch { res.status(401).json({ error: 'Pehle login karo' }); }
}
function access(u) {
  const now = Date.now();
  const trialEnd = new Date(u.created_at).getTime() + TRIAL_DAYS * DAY;
  const subActive = u.sub_end && new Date(u.sub_end).getTime() > now && ['active', 'authenticated', 'cancelled', 'completed'].includes(u.sub_status);
  const subOn = u.sub_status === 'active' || subActive;
  return { subscribed: !!subOn, trialEnd, trialLeftMs: Math.max(0, trialEnd - now), allowed: !!subOn || now < trialEnd };
}
const publicUser = u => ({ id: u.id, email: u.email, name: u.name, ...access(u), subStatus: u.sub_status, subEnd: u.sub_end });
const validEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

// ---- auth
app.get('/api/config', (_, res) => res.json({ googleClientId: E.GOOGLE_CLIENT_ID, razorpayKey: E.RAZORPAY_KEY_ID, trialDays: TRIAL_DAYS }));

app.post('/api/auth/google', async (req, res) => {
  try {
    const t = await gclient.verifyIdToken({ idToken: req.body.credential, audience: E.GOOGLE_CLIENT_ID });
    const p = t.getPayload();
    if (!p.email_verified) return res.status(400).json({ error: 'Email verify nahi hai' });
    const r = await pool.query(`INSERT INTO users(email,name) VALUES($1,$2)
      ON CONFLICT(email) DO UPDATE SET name=COALESCE(users.name,EXCLUDED.name) RETURNING *`, [p.email.toLowerCase(), p.name]);
    setCookie(res, r.rows[0]); res.json(publicUser(r.rows[0]));
  } catch (e) { console.error(e.message); res.status(400).json({ error: 'Google login fail hua' }); }
});

app.post('/api/auth/signup', async (req, res) => {
  const email = String(req.body.email || '').toLowerCase().trim(), pw = String(req.body.password || '');
  if (!validEmail(email)) return res.status(400).json({ error: 'Sahi email daalo' });
  if (pw.length < 8) return res.status(400).json({ error: 'Password kam se kam 8 akshar ka ho' });
  try {
    const r = await pool.query('INSERT INTO users(email,name,pass_hash) VALUES($1,$2,$3) RETURNING *',
      [email, email.split('@')[0], await bcrypt.hash(pw, 10)]);
    setCookie(res, r.rows[0]); res.json(publicUser(r.rows[0]));
  } catch (e) { res.status(400).json({ error: 'Ye email pehle se hai, login karo' }); }
});

app.post('/api/auth/login', rateLimit({ windowMs: 15 * 60e3, max: 20 }), async (req, res) => {
  const r = await pool.query('SELECT * FROM users WHERE email=$1', [String(req.body.email || '').toLowerCase().trim()]);
  const u = r.rows[0];
  if (!u || !u.pass_hash || !(await bcrypt.compare(String(req.body.password || ''), u.pass_hash)))
    return res.status(400).json({ error: 'Email ya password galat hai (Google se bana ho toh Google se login karo)' });
  setCookie(res, u); res.json(publicUser(u));
});

app.post('/api/auth/logout', (_, res) => { res.clearCookie('t'); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => res.json(publicUser(req.user)));

// ---- image generation
app.post('/api/generate', auth, rateLimit({ windowMs: 60e3, max: 12 }), async (req, res) => {
  const u = req.user, a = access(u);
  if (!a.allowed) return res.status(402).json({ error: 'Free trial khatam. ₹99/month subscribe karo.' });
  let { prompt, model = 'fast', size = 'square', style = 'none', count = 1, seed } = req.body;
  prompt = String(prompt || '').trim();
  if (prompt.length < 3 || prompt.length > 1000) return res.status(400).json({ error: 'Prompt 3 se 1000 akshar ka ho' });
  if (!MODELS[model]) model = 'fast';
  count = Math.min(Math.max(+count || 1, 1), 4);
  const used = await pool.query(`SELECT count(*)::int c FROM images WHERE user_id=$1 AND created_at > now()-interval '1 day'`, [u.id]);
  if (used.rows[0].c + count > DAILY_LIMIT) return res.status(429).json({ error: `Aaj ki limit (${DAILY_LIMIT} images) poori ho gayi` });
  try {
    const body = { prompt: prompt + (STYLES[style] || ''), image_size: SIZES[size] || 'square_hd', num_images: count, enable_safety_checker: true };
    if (seed !== undefined && seed !== '') body.seed = +seed;
    if (model === 'fast') body.num_inference_steps = 4;
    const r = await fetch('https://fal.run/' + MODELS[model], {
      method: 'POST', headers: { Authorization: 'Key ' + E.FAL_KEY, 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    const d = await r.json();
    if (!r.ok || !d.images) throw new Error(JSON.stringify(d).slice(0, 300));
    const urls = d.images.map(i => i.url);
    for (const url of urls) await pool.query('INSERT INTO images(user_id,url,prompt,model) VALUES($1,$2,$3,$4)', [u.id, url, prompt, model]);
    res.json({ images: urls, seed: d.seed });
  } catch (e) { console.error('gen', e.message); res.status(502).json({ error: 'Image nahi bani, dobara try karo' }); }
});

app.get('/api/gallery', auth, async (req, res) => {
  const r = await pool.query('SELECT id,url,prompt,created_at FROM images WHERE user_id=$1 ORDER BY created_at DESC LIMIT 60', [req.user.id]);
  res.json(r.rows);
});
app.delete('/api/gallery/:id', auth, async (req, res) => {
  await pool.query('DELETE FROM images WHERE id=$1 AND user_id=$2', [+req.params.id, req.user.id]); res.json({ ok: true });
});

// ---- subscription
const rz = (p, body) => fetch('https://api.razorpay.com/v1' + p, {
  method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Basic ' + Buffer.from(E.RAZORPAY_KEY_ID + ':' + E.RAZORPAY_KEY_SECRET).toString('base64') },
  body: JSON.stringify(body || {})
}).then(async r => { const d = await r.json(); if (!r.ok) throw new Error(JSON.stringify(d)); return d; });

app.post('/api/subscribe', auth, async (req, res) => {
  try {
    if (access(req.user).subscribed) return res.status(400).json({ error: 'Subscription pehle se active hai' });
    const s = await rz('/subscriptions', { plan_id: E.RAZORPAY_PLAN_ID, total_count: 120, customer_notify: 1, notes: { user_id: String(req.user.id), email: req.user.email } });
    await pool.query('UPDATE users SET sub_id=$1, sub_status=$2 WHERE id=$3', [s.id, s.status, req.user.id]);
    res.json({ subscriptionId: s.id });
  } catch (e) { console.error(e.message); res.status(500).json({ error: 'Payment shuru nahi hua' }); }
});

app.post('/api/subscribe/verify', auth, async (req, res) => {
  const { razorpay_payment_id: p, razorpay_subscription_id: s, razorpay_signature: sig } = req.body;
  const exp = crypto.createHmac('sha256', E.RAZORPAY_KEY_SECRET).update(p + '|' + s).digest('hex');
  if (s !== req.user.sub_id || !sig || sig.length !== exp.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(exp)))
    return res.status(400).json({ error: 'Payment verify nahi hua' });
  const end = new Date(Date.now() + 31 * DAY); // webhook baad me exact date se update kar dega
  await pool.query(`UPDATE users SET sub_status='active', sub_end=$1 WHERE id=$2`, [end, req.user.id]);
  res.json({ ok: true });
});

app.post('/api/subscribe/cancel', auth, async (req, res) => {
  try { await rz(`/subscriptions/${req.user.sub_id}/cancel`, { cancel_at_cycle_end: 1 }); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ error: 'Cancel nahi hua' }); }
});

app.get('*', (_, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
init().then(() => app.listen(E.PORT || 3000, () => console.log('Pixora live'))).catch(e => { console.error(e); process.exit(1); });
